
package espe.edu.ec.CoopLatinaMarco.controller;

import espe.edu.ec.CoopLatinaMarco.model.Passenger;




/**
 *
 * @author Loor Cesar,DDCO-ESPE,GADC.MSI
 */
public class PassengerController extends BasicController<Passenger>{

    public PassengerController(Passenger object, String collectionName) {
        super(object, collectionName);
    }
        
    
}
