
package espe.edu.ec.CoopLatinaMarco.controller;
import espe.edu.ec.CoopLatinaMarco.model.TicketPassager;

/**
 *
 * @author aldma
 */
public class TicketController extends BasicController<TicketPassager>{

    public TicketController(TicketPassager object, String collectionName) {
        super(object, collectionName);
    }
    
}
