
package espe.edu.ec.CoopLatinaMarco.model;

import org.bson.Document;



/**
 *
 * @author Loor Cesar,DDCO-ESPE,GADC.MSI
 */
public abstract class BasicModel {
     public abstract Document buildDocument();
}
