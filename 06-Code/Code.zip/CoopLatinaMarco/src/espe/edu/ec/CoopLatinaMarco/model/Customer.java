
package espe.edu.ec.CoopLatinaMarco.model;

/**
 *
 * @author Loor Cesar,DDCO-ESPE,GADC.MSI
 */
public class Customer {
    
}
