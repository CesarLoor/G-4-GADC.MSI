
package espe.edu.ec.CoopLatinaMarco.model;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Loor Cesar,DDCO-ESPE,GADC.MSI
 */
public class BusTest {
    
    public BusTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of toString method, of class Bus.
     */
    @Test
    public void testToString() {
        System.out.println("toString");
        Bus instance = null;
        String expResult = "";
        String result = instance.toString();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getId method, of class Bus.
     */
    @Test
    public void testGetId() {
        System.out.println("getId");
        Bus instance = null;
        int expResult = 0;
        int result = instance.getId();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setId method, of class Bus.
     */
    @Test
    public void testSetId() {
        System.out.println("setId");
        int id = 0;
        Bus instance = null;
        instance.setId(id);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getMatricule method, of class Bus.
     */
    @Test
    public void testGetMatricule() {
        System.out.println("getMatricule");
        Bus instance = null;
        String expResult = "";
        String result = instance.getMatricule();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setMatricule method, of class Bus.
     */
    @Test
    public void testSetMatricule() {
        System.out.println("setMatricule");
        String matricule = "";
        Bus instance = null;
        instance.setMatricule(matricule);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getNameOfDriver method, of class Bus.
     */
    @Test
    public void testGetNameOfDriver() {
        System.out.println("getNameOfDriver");
        Bus instance = null;
        String expResult = "";
        String result = instance.getNameOfDriver();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setNameOfDriver method, of class Bus.
     */
    @Test
    public void testSetNameOfDriver() {
        System.out.println("setNameOfDriver");
        String nameOfDriver = "";
        Bus instance = null;
        instance.setNameOfDriver(nameOfDriver);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getRoute method, of class Bus.
     */
    @Test
    public void testGetRoute() {
        System.out.println("getRoute");
        Bus instance = null;
        int expResult = 0;
        int result = instance.getRoute();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setRoute method, of class Bus.
     */
    @Test
    public void testSetRoute() {
        System.out.println("setRoute");
        int route = 0;
        Bus instance = null;
        instance.setRoute(route);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getid method, of class Bus.
     */
    @Test
    public void testGetid() {
        System.out.println("getid");
        Bus instance = null;
        Object expResult = null;
        Object result = instance.getid();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getmatricule method, of class Bus.
     */
    @Test
    public void testGetmatricule() {
        System.out.println("getmatricule");
        Bus instance = null;
        Object expResult = null;
        Object result = instance.getmatricule();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getnameOfDriver method, of class Bus.
     */
    @Test
    public void testGetnameOfDriver() {
        System.out.println("getnameOfDriver");
        Bus instance = null;
        Object expResult = null;
        Object result = instance.getnameOfDriver();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getroute method, of class Bus.
     */
    @Test
    public void testGetroute() {
        System.out.println("getroute");
        Bus instance = null;
        Object expResult = null;
        Object result = instance.getroute();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
